const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const typingIndicator = document.getElementById('typing-indicator');

function formatTime(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Backend selection
let backend = localStorage.getItem('chat_backend') || 'php';
let currentController = null;

function setBackend(newBackend) {
    backend = newBackend;
    localStorage.setItem('chat_backend', backend);
    if (document.getElementById('backend-indicator')) {
        document.getElementById('backend-indicator').textContent = backend.toUpperCase();
    }
}

function appendMessage(sender, text, timestamp, backendLabel) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${sender}`;
    const bubble = document.createElement('div');
    bubble.className = `bubble ${sender}`;
    bubble.textContent = text;
    msgDiv.appendChild(bubble);

    const metaDiv = document.createElement('div');
    metaDiv.className = 'timestamp';

    const timeText = document.createTextNode((timestamp || formatTime(new Date())));
    metaDiv.appendChild(timeText);

    if (backendLabel) {
        const badge = document.createElement('span');
        badge.className = 'backend-badge';
        badge.textContent = backendLabel;
        metaDiv.appendChild(badge);
    }

    msgDiv.appendChild(metaDiv);

    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function saveHistory() {
    localStorage.setItem('chatHistory', chatMessages.innerHTML);
}

function showToast(message, type = 'info', timeout = 4000) {
    try {
        const container = document.getElementById('toast-container');
        if (!container) return;
        const t = document.createElement('div');
        t.className = 'toast ' + (type === 'error' ? 'error' : 'info');
        t.textContent = message;
        container.appendChild(t);
        // Force reflow to allow animation
        setTimeout(() => t.classList.add('show'), 10);
        setTimeout(() => {
            t.classList.remove('show');
            setTimeout(() => { try { container.removeChild(t); } catch (e) {} }, 300);
        }, timeout);
    } catch (e) { console.warn('Toast error', e); }
}

function loadHistory() {
    const history = localStorage.getItem('chatHistory');
    if (history) {
        chatMessages.innerHTML = history;
    }
}

function clearHistory() {
    localStorage.removeItem('chatHistory');
    chatMessages.innerHTML = '';
}

// Welcome banner controls: collapse/expand for better UX
function collapseWelcome() {
    const banner = document.querySelector('.welcome-banner');
    if (banner && !banner.classList.contains('collapsed')) {
        banner.classList.add('collapsed');
    }
}
function expandWelcome() {
    const banner = document.querySelector('.welcome-banner');
    if (banner && banner.classList.contains('collapsed')) {
        banner.classList.remove('collapsed');
    }
}

async function getAIResponse(input, signal = null) {
    // Choose backend URL
    let url;
    if (backend === 'php') {
        // Prefer same-origin relative path so it works under Apache/XAMPP
        url = window.location.origin + '/backend_php/api.php';
    } else {
        // Python backend (local dev)
        url = 'http://localhost:5000/api/chat';
    }

    try {
        const options = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: input })
        };
        if (signal) options.signal = signal;

        const res = await fetch(url, options);

        if (!res.ok) {
            const err = await res.json().catch(() => null);
            const msg = err?.error || err?.message || `HTTP ${res.status}`;
            return { text: 'Error: ' + msg, backend: backend };
        }

        const data = await res.json();
        const reply = data.reply || data.response || data.error || 'No reply';
        let backendLabel = (backend === 'php') ? 'php' : (data.backend || backend);
        if (data && data.source === 'custom') backendLabel = `${backendLabel} (custom)`;
        return { text: reply, backend: backendLabel };
    } catch (e) {
        if (e.name === 'AbortError') {
            return { text: 'Request canceled', backend: backend, canceled: true };
        }
        return { text: 'Error: Unable to reach backend (' + backend + ')', backend: backend };
    }
}

async function handleSend() {
    // If a request is active, clicking Send will cancel it
    if (currentController) {
        currentController.abort();
        showToast('Request canceled', 'info');
        return;
    }

    // collapse welcome banner so chat moves up
    collapseWelcome();

    try {
        const input = userInput.value;
        if (!input.trim()) return;

        // prepare abort controller and UI state
        const controller = new AbortController();
        currentController = controller;

        sendBtn.disabled = true;
        sendBtn.classList.add('pending');
        sendBtn.setAttribute('aria-pressed', 'true');
        sendBtn.querySelector('.btn-text').textContent = 'Cancel';
        userInput.disabled = true;

        // disable backend switch while pending
        const bpy = document.getElementById('backend-python');
        const bphp = document.getElementById('backend-php');
        if (bpy) bpy.disabled = true;
        if (bphp) bphp.disabled = true;

        console.log('Sending message:', input);
        appendMessage('user', input, formatTime(new Date()));
        saveHistory();
        userInput.value = '';
        typingIndicator.style.display = 'block';
        typingIndicator.setAttribute('aria-hidden', 'false');

        // Call backend with abort signal
        const aiReply = await getAIResponse(input, controller.signal);

        // If canceled, show toast and skip appending AI message
        if (aiReply && aiReply.canceled) {
            showToast('Request canceled', 'info');
            return;
        }

        if (aiReply && aiReply.text && aiReply.text.startsWith('Error:')) {
            showToast(aiReply.text, 'error');
        }

        appendMessage('ai', aiReply.text, formatTime(new Date()), aiReply.backend ? aiReply.backend.toUpperCase() : '');
        typingIndicator.style.display = 'none';
        typingIndicator.setAttribute('aria-hidden', 'true');
        saveHistory();

        // Optionally read AI reply aloud if enabled
        try {
            const readEnabled = localStorage.getItem('nutron_read_aloud') === 'true';
            if (readEnabled && 'speechSynthesis' in window) {
                const utter = new SpeechSynthesisUtterance(aiReply.text);
                utter.lang = 'en-US';
                utter.rate = 1;
                window.speechSynthesis.cancel();
                window.speechSynthesis.speak(utter);
            }
        } catch (e) {
            console.warn('Speech synthesis error', e);
        }
    } catch (err) {
        if (err && err.name === 'AbortError') {
            // already handled via aiReply.canceled
            console.log('Request aborted');
        } else {
            console.error('Error in handleSend:', err);
            appendMessage('ai', 'An error occurred while sending your message. Please try again.', formatTime(new Date()));
            showToast('An error occurred while sending your message.', 'error');
        }
    } finally {
        // cleanup UI and controller
        currentController = null;
        sendBtn.disabled = false;
        sendBtn.classList.remove('pending');
        sendBtn.setAttribute('aria-pressed', 'false');
        const btnText = sendBtn.querySelector('.btn-text');
        if (btnText) btnText.textContent = 'Send';
        userInput.disabled = false;
        userInput.focus();
        const bpy = document.getElementById('backend-python');
        const bphp = document.getElementById('backend-php');
        if (bpy) bpy.disabled = false;
        if (bphp) bphp.disabled = false;
    }
}

sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleSend();
});

// handle form submit as well (in case button types or markup change)
const chatForm = document.querySelector('.chat-input-area');
if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        handleSend();
    });
}

// Backend switcher
window.addEventListener('DOMContentLoaded', () => {
    loadHistory();
    // Always set PHP as default backend on first load
    setBackend('php');
    // ensure typing indicator is hidden to assist screen readers
    typingIndicator.setAttribute('aria-hidden', 'true');
    if (document.getElementById('backend-indicator')) {
        document.getElementById('backend-indicator').textContent = backend.toUpperCase();
        document.getElementById('backend-python').addEventListener('click', () => setBackend('python'));
        document.getElementById('backend-php').addEventListener('click', () => setBackend('php'));
    }

    // Speech / Microphone setup
    const micBtn = document.getElementById('mic-btn');
    const micStatus = document.getElementById('mic-status');
    const readToggle = document.getElementById('read-aloud-toggle');

    let recognition = null;
    let listening = false;

    // initialize read-aloud state
    try {
        const readAloud = localStorage.getItem('nutron_read_aloud') === 'true';
        if (readToggle) {
            readToggle.checked = readAloud;
            readToggle.addEventListener('change', (e) => {
                localStorage.setItem('nutron_read_aloud', e.target.checked ? 'true' : 'false');
            });
        }
    } catch (e) {
        console.warn('Could not access localStorage for read-aloud preference', e);
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition && micBtn) {
        recognition = new SpeechRecognition();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.onresult = (e) => {
            const transcript = Array.from(e.results).map(r => r[0].transcript).join('');
            userInput.value = transcript;
            stopListening();
            setTimeout(() => { handleSend(); }, 250);
        };

        recognition.onend = () => {
            if (listening) stopListening();
        };

        recognition.onerror = (e) => {
            console.error('Speech recognition error', e);
            stopListening();
            // show a friendly alert for common errors
            if (e.error) alert('Speech recognition error: ' + e.error);
        };

        function startListening() {
            if (!recognition) return;
            listening = true;
            micBtn.classList.add('listening');
            if (micStatus) { micStatus.style.display = 'inline'; micStatus.textContent = 'Listening...'; }
            try { recognition.start(); } catch (err) { console.warn(err); }
        }
        function stopListening() {
            if (!recognition) return;
            listening = false;
            micBtn.classList.remove('listening');
            if (micStatus) micStatus.style.display = 'none';
            try { recognition.stop(); } catch (err) { console.warn(err); }
        }

        micBtn.addEventListener('click', () => {
            if (listening) stopListening(); else startListening();
        });
    } else {
        if (micBtn) { micBtn.disabled = true; micBtn.title = 'Voice input not supported in this browser'; }
    }

    // hide welcome banner if there are existing messages (history)
    if (chatMessages.querySelector('.message')) {
        collapseWelcome();
    }

    // add new chat button handler
    const newChatBtn = document.getElementById('new-chat-btn');
    const saveChatBtn = document.getElementById('save-chat-btn');
    const convList = document.getElementById('conversations-list');

    if (newChatBtn) {
        newChatBtn.addEventListener('click', () => {
            clearHistory();
            expandWelcome();
        });
    }

    if (saveChatBtn) {
        saveChatBtn.addEventListener('click', () => {
            // simple save: store current HTML chat content under a timestamped key and list it
            const key = 'nutron_conv_' + Date.now();
            const title = 'Conversation ' + new Date().toLocaleString();
            const payload = { title, content: chatMessages.innerHTML };
            localStorage.setItem(key, JSON.stringify(payload));

            // add to list UI
            const li = document.createElement('li');
            li.textContent = title;
            li.dataset.key = key;
            li.addEventListener('click', () => {
                const data = JSON.parse(localStorage.getItem(li.dataset.key));
                if (data) {
                    chatMessages.innerHTML = data.content;
                    collapseWelcome();
                }
            });
            convList.prepend(li);
        });
    }

    // load saved convs
    if (convList) {
        for (let i = localStorage.length - 1; i >= 0; i--) {
            const k = localStorage.key(i);
            if (k && k.startsWith('nutron_conv_')) {
                try {
                    const data = JSON.parse(localStorage.getItem(k));
                    const li = document.createElement('li');
                    li.textContent = data.title || k;
                    li.dataset.key = k;
                    li.addEventListener('click', () => {
                        const d = JSON.parse(localStorage.getItem(li.dataset.key));
                        if (d) {
                            chatMessages.innerHTML = d.content;
                            collapseWelcome();
                        }
                    });
                    convList.appendChild(li);
                } catch (e) { /* ignore parse errors */ }
            }
        }
    }

    // clicking the welcome banner collapses it
    const welcomeBanner = document.querySelector('.welcome-banner');
    if (welcomeBanner) welcomeBanner.addEventListener('click', collapseWelcome);
});