#!/usr/bin/env python3
import os
import sys
import json

try:
    import openai
except Exception:
    print(json.dumps({"error": "Missing dependency 'openai'. Install with: pip install -r requirements.txt"}))
    sys.exit(1)


def main():
    try:
        payload = sys.stdin.read()
        data = json.loads(payload) if payload else {}
        message = data.get("message", "")
        context = data.get("context", [])

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            print(json.dumps({"error": "OPENAI_API_KEY not set"}))
            return

        openai.api_key = api_key

        # Build messages with a small system instruction and recent context
        messages = [{"role": "system", "content": "You are a helpful assistant."}]
        for msg in context[-6:]:
            messages.append({"role": "user", "content": msg})
        messages.append({"role": "user", "content": message})

        resp = openai.ChatCompletion.create(
            model="gpt-40-mini",
            messages=messages,
            temperature=0.7,
            max_tokens=500
        )

        reply = resp["choices"][0]["message"]["content"].strip()
        print(json.dumps({"reply": reply, "model": resp.get("model", "gpt-40-mini")}))

    except Exception as e:
        print(json.dumps({"error": str(e)}))


if __name__ == "__main__":
    main()
