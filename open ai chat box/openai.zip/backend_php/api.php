<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

session_start();

$input = json_decode(file_get_contents("php://input"), true);
$userMessage = strtolower(trim($input['message'] ?? ''));

if (!$userMessage) {
    echo json_encode(["reply" => "Please say something 🙂"]);
    exit;
}

/* -------------------------------
   Conversation memory
-------------------------------- */
if (!isset($_SESSION['context'])) {
    $_SESSION['context'] = [];
}
$_SESSION['context'][] = $userMessage;

/* -------------------------------
   Knowledge base
-------------------------------- */
$knowledge = [
    "hello" => [
        "Hi 👋 I'm Nutron Chat.",
        "Hello! How can I help you today?",
        "Hey there 😊"
    ],
    "who are you" => [
        "I'm Nutron Chat, your website's AI assistant.",
        "I'm a locally running AI chatbot — no internet needed."
    ],
    "what is ai" => [
        "AI stands for Artificial Intelligence. It enables machines to think and act like humans."
    ],
    "machine learning" => [
        "Machine Learning is a subset of AI that learns from data instead of rules."
    ],
    "help" => [
        "You can ask about AI, Machine Learning, or how this website works."
    ],
    "bye" => [
        "Goodbye 👋 Have a great day!",
        "See you soon 😊"
    ]
];

/* -------------------------------
   Intent matching
-------------------------------- */
$response = null;

foreach ($knowledge as $key => $answers) {
    if (str_contains($userMessage, $key)) {
        $response = $answers[array_rand($answers)];
        break;
    }
}

/* -------------------------------
   Context-aware fallback (try Python OpenAI worker)
-------------------------------- */
if (!$response) {
    $payload = json_encode([
        'message' => $userMessage,
        'context' => $_SESSION['context']
    ]);

    // Choose python binary depending on OS
    $pythonBin = PHP_OS_FAMILY === 'Windows' ? 'python' : 'python3';
    $script = __DIR__ . '/../backend_python/chat.py';
    $descriptorspec = [
        0 => ["pipe", "r"],
        1 => ["pipe", "w"],
        2 => ["pipe", "w"]
    ];

    $command = $pythonBin . ' ' . escapeshellarg($script);
    $process = proc_open($command, $descriptorspec, $pipes, __DIR__);

    if (is_resource($process)) {
        fwrite($pipes[0], $payload);
        fclose($pipes[0]);

        $pythonOutput = stream_get_contents($pipes[1]);
        fclose($pipes[1]);

        $pythonError = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $return_value = proc_close($process);

        $decoded = json_decode($pythonOutput, true);
        if (isset($decoded['reply']) && $decoded['reply']) {
            $response = $decoded['reply'];
        } else {
            // fallback to simple rule-based reply
            $last = end($_SESSION['context']);
            if (str_contains($last, "your name")) {
                $response = "I'm Nutron Chat 🙂";
            } else {
                $response = "I'm still learning. Try asking about AI, ML, or say hello!";
            }
        }
    } else {
        $last = end($_SESSION['context']);
        if (str_contains($last, "your name")) {
            $response = "I'm Nutron Chat 🙂";
        } else {
            $response = "I'm still learning. Try asking about AI, ML, or say hello!";
        }
    }
}

echo json_encode([
    "reply" => $response,
    "backend" => "php-local-ai"
]);
